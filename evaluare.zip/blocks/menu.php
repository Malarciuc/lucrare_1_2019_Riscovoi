<ul style="display: inline-flex;">
    <li><a href="index.php">Acasa</a>
    <li><a href="index.php?page=products_new">Creare produs</a>
    <li><a href="index.php?page=products_list">Lista produse</a>
    <li><a href="index.php?page=logout">Logout</a>
</ul>