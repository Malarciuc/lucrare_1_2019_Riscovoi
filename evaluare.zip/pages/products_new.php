<?
if(!empty($_POST['name'])) {
	

	$result = mysqli_query($connection, "SELECT * FROM product");

	//mysqli_query($connection, "INSERT INTO students (name, age) VALUES ('{$_POST['name']}', {$_POST['age']})");
	if(mysqli_query($connection, "INSERT INTO product SET denumire = '{$_POST['denumire']}', pret = {$_POST['pret']} , id_cat = {$_POST['categorie']}")) {
		echo 'Succes';
	} else {
		echo 'Eroare';
	}
} else {
?>
<form action="" method="post">
	Name <input type="text" name="denumire">
	<br>
    Pret <input type="text" name="pret">
    <br>
	Categorie <br>
	<select name="categorie">
	 	<?
            $categories = mysqli_query($connection, 'SELECT * from categories');
            while ($cat = mysqli_fetch_assoc($categories)){


        ?>
		<option value="<?=$cat['id'];?>"><?=$cat['denumire'];?></option>
		<? }?>
	</select>
	<br>
	<input type="submit" value="adauga produs">
</form>

<?}?>