<?
if(isset($_GET['id']) && isset($_GET['action']) && $_GET['action'] === 'delete'){
    if(mysqli_query($connection, "DELETE FROM product WHERE id = {$_GET['id']}" )) {
        echo 'Succes';
    } else {
        echo 'Eroare';
    }
}

$result = mysqli_query($connection, "SELECT DISTINCT product.denumire, product.pret, categories.denumire as categorie FROM product inner join categories on product.id_cat = categories.id ");
?>
<table border="1">
<? while($product = mysqli_fetch_assoc($result)){?>
<tr>
	<td><?= $product['denumire']?></td>
	<td><?= $product['pret']?></td>
    <td><?= $product['categorie']?></td>
	<td>
    <a href="?page=products_list&action=delete&id=<?= $product['id']?>" onclick="return confirm('Doriti sa stergeti inregistrarea?')">x</a>
    <a href="?page=products_edit&product_id=<?= $product['id']?>">m</a>
  </td>
</tr>
<? }?>
