<? $current_product = mysqli_query($connection,"select * from product where id = $_POST[product_id] ");
    $prod = mysqli_fetch_assoc($current_product);

if(!empty($_POST['edit_id'])) {


    if(mysqli_query($connection, "UPDATE product SET denumire = '{$_POST['denumire']}', pret = {$_POST['pret']} , id_cat = {$_POST['edit_id']}")) {
        echo 'Succes';
    } else {
        echo 'Eroare';
    }
} else {
    ?>
    <form action="" method="post">
        <input type="hidden" value="<?=$prod['id']?>" name="edit_id">
        Name <input type="text" name="denumire" value="<?=$prod['denumire']?>">
        <br>
        Pret <input type="text" name="pret" value="<?=$prod['pret']?>">
        <br>
        Categorie <br>
        <select name="categorie">
            <?
            $categories = mysqli_query($connection, 'SELECT * from categories');
            while ($cat = mysqli_fetch_assoc($categories)){


                ?>
                <option value="<?=$cat['id'];?>"><?=$cat['denumire'];?></option>
            <? }?>
        </select>
        <br>
        <input type="submit" value="adauga produs">
    </form>

<?}?>