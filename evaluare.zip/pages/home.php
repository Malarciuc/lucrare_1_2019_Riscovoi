Home Page

<?= $_SESSION['myMessage']?>